"use strict"; module.exports = {
    open_panel: "Optional build",
    description: "Help your life easy =)))",
    welcome: "DUCBEE PLAYABLE BUILD TOOL FOR COCOS 3.6.0",
    step_1: "P1: Cho tôi 10k và tạo 2 biến mindworks và vungle  ",
    step_2: "P2: Thêm dòng sau vào hàm Start() ==> if (this.mindworks){window.gameReady && window.gameReady(); ",
    step_3: "P3: Thêm hàm này vào dưới cùng của scripts ==> EventNetWork() {if (this.mindworks) {window.gameEnd && window.gameEnd();}if (this.vungle) {parent.postMessage('complete', '*');} ",
    step_4: "P4: Nếu muốn build Mintengral thì bật true biến mindworks ở trên lên rồi bấm build lại, rồi đóng zip ",

    supportAds: "Hỗ trợ build: [AppLovin] [IronSource] [Mintengral] [Unity]",
    canbuildAds: "Đang phát triển: [Facebook] [Google] [Liftoff] [Moloco] [Pangle] [Rubeex] [Tiktok]",

    behavior:"STATUS: ",
    get_help: "About me ! DucBeeeeee",
    cancel: "Cancel (X)",
    pack: "Build (V)",
};